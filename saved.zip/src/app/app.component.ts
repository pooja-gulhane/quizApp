import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  //title = 'my-app';
  textColor: string ;
  h : number;
  w : number;

constructor()
{
  this.textColor = 'black';
  this.h = 612;
  this.w = 612;
}


changeColor(color:string)
{
  this.textColor = color;
}

increaseSize() {
  this.h += 20; 
  this.w += 20; 
}

decreaseSize()
{
  this.h -= 20;
  this.w -= 20;
}

}

